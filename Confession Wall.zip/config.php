<?php
$conn=mysqli_connect("localhost","xcbbq","040216","xcbbq");
$conns=mysqli_connect("localhost","xcbbq","040216","information_schema");
//你的数据库信息
$px=25              
//每页显示表白数
?>