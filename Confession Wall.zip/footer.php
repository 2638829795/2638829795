<!--footer-->
<footer>
    <div class="mdui-divider"></div>
    <center><p>Copyright &copy;2020-<?php echo date("Y"); ?> <a class="mdui-text-color-grey-800" href='www.yi.confession.red'>亦云</a> All Rights Reserved.</p><center>
</footer>