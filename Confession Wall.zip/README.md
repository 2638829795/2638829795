# Lovewall
[![](https://data.jsdelivr.com/v1/package/gh/soxft/lovewall/badge)](https://www.jsdelivr.com/package/gh/soxft/lovewall)
<a href="http://www.apache.org/licenses/LICENSE-2.0.html"> 
<img src="https://img.shields.io/github/license/soxft/lovewall.svg" alt="License"></a>
<a href="https://github.com/soxft/lovewall/stargazers"> 
<img src="https://img.shields.io/github/stars/soxft/lovewall.svg" alt="GitHub stars"></a>
<a href="https://github.com/soxft/lovewall/network/members"> 
<img src="https://img.shields.io/github/forks/soxft/lovewall.svg" alt="GitHub forks"></a> 
## 简介
  一款极简表白墙
## 安装方法
1.下载源码.
<br/>2.解压压缩包.
<br/>3.上传源码至服务器.
<br/>4.访问网站,根据引导输入mysql等信息进行安装.
<br/>5.访问域名进行确认.
## 演示站点
http://love.xsot.cn
## 最后
有任何问题,请访问http://blog.xsot.cn/archives/pro-bbq.html 进行留言
## 更新
V2.2更新_2020/03/04
<br/>1.更新install.php安装程序.
<br/>2.取消后台管理.
<br/>3.修改前台样式,力求极简化.

V2.1更新_2019/07/17
<br/>1.更新install.php安装程序.
<br/>2.将登录登出文件移至/admin中.

V2.0更新_2019/06/27
<br/>1.更新了管理系统.
<br/>2.修改结构.
<br/>3.将原先的GET登录方式全部改为SESSION.
